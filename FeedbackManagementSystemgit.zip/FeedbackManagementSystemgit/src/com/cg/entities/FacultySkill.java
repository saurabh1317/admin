

package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name="Faculty_Skill")
public class FacultySkill {
    
	@Id
//   @Column(name="Faculty_Id")
	private int facultyId;
	
//    @Column(name="Employee_Name")
    private String facultyName;
    
//    @Column(name="Password")
    private String password;
    
//    @Column(name="Role")
    private String role;

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

	
	
	
	
}
