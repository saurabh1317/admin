package com.cg.entities;

public class TrainingParticipantEnrollment {

}
