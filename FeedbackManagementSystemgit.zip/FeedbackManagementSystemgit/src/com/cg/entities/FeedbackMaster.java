package com.cg.entities;

public class FeedbackMaster {

}
