package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.CourseMaster;
import com.cg.entities.EmployeeMaster;
@Repository
public class FeedbackManagementSystemDaoImpl implements IFeedbackManagementSystemDao {

	@PersistenceContext
	EntityManager manager;

	
	public EntityManager getManager() {
		return manager;
	}


	public void setManager(EntityManager manager) {
		this.manager = manager;
	}
	
	@Override
	public Boolean LoginUser(EmployeeMaster employee) {
		EmployeeMaster emp=manager.find(EmployeeMaster.class, employee.getEmployeeId());
		
		if((emp.getEmployeeId()==employee.getEmployeeId()))
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}

	@Override
	public EmployeeMaster RegisterNewUser(EmployeeMaster employee) {
		manager.persist(employee);
		return employee;
	}

	@Override
	public EmployeeMaster ForgetPassword(EmployeeMaster employee) {
		EmployeeMaster emp=manager.find(EmployeeMaster.class, employee.getEmployeeId());
        emp.setPassword(employee.getPassword());
        manager.merge(emp);
		return employee;
	}


	@Override
	public CourseMaster AddNewCourse(CourseMaster course) {
		manager.persist(course);
		return course;
	}


	@Override
	public List<CourseMaster> ListAllCourse() {
		String query="select course from CourseMaster course";
		TypedQuery<CourseMaster> tQuery=manager.createQuery(query, CourseMaster.class);
		List<CourseMaster> elist=tQuery.getResultList();
		return elist;
		
	}


	@Override
	public CourseMaster UpdateCourse(CourseMaster course) {
		CourseMaster cou=	manager.find(CourseMaster.class, course.getCourseId());
          cou.setCourseName(course.getCourseName());
          cou.setDuration(course.getDuration());
		
		return cou;
	}


	@Override
	public CourseMaster DeleteCourse(int courseId) {
		Query query=manager.createQuery("delete from CourseMaster course where course.courseId= "+courseId);
		query.executeUpdate();
		return null;
		
	}


	@Override
	public CourseMaster SearchCourse(int courseId) {
	CourseMaster cou=	manager.find(CourseMaster.class, courseId);
		return cou;
	}

}
