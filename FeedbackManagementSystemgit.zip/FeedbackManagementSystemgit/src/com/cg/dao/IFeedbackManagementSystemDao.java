package com.cg.dao;

import java.util.List;

import com.cg.entities.CourseMaster;
import com.cg.entities.EmployeeMaster;

public interface IFeedbackManagementSystemDao {

	public Boolean LoginUser(EmployeeMaster employee);
	
	public EmployeeMaster RegisterNewUser(EmployeeMaster employee);
	
	public EmployeeMaster ForgetPassword(EmployeeMaster employee);
	
	public CourseMaster AddNewCourse(CourseMaster course);
	
	public List<CourseMaster> ListAllCourse();
	
	public CourseMaster UpdateCourse(CourseMaster course);
	
	public CourseMaster DeleteCourse(int courseId);
	
	public CourseMaster SearchCourse(int courseId);

}
