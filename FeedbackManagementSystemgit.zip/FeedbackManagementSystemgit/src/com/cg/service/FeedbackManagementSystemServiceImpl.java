package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IFeedbackManagementSystemDao;
import com.cg.entities.CourseMaster;
import com.cg.entities.EmployeeMaster;


@Service
@Transactional

public class FeedbackManagementSystemServiceImpl implements IFeedbackManagementSystemService {

	
	@Autowired
	IFeedbackManagementSystemDao dao;
	
	
	
	public IFeedbackManagementSystemDao getDao() {
		return dao;
	}

	public void setDao(IFeedbackManagementSystemDao dao) {
		this.dao = dao;
	}

	@Override
	public Boolean LoginUser(EmployeeMaster employee) {
		return dao.LoginUser(employee);
	}

	@Override
	public EmployeeMaster RegisterNewUser(EmployeeMaster employee) {
		return dao.RegisterNewUser(employee);
	}

	@Override
	public EmployeeMaster ForgetPassword(EmployeeMaster employee) {
		return dao.ForgetPassword(employee);
	}

	@Override
	public CourseMaster AddNewCourse(CourseMaster course) {
		return dao.AddNewCourse(course);
	}

	@Override
	public List<CourseMaster> ListAllCourse() {
		return dao.ListAllCourse();
	}

	@Override
	public CourseMaster UpdateCourse(CourseMaster course) {
		return dao.UpdateCourse(course);
	}

	@Override
	public CourseMaster DeleteCourse(int courseId) {
		return dao.DeleteCourse(courseId);
	}

	@Override
	public CourseMaster SearchCourse(int courseId) {
		return dao.SearchCourse(courseId);
	}

}
