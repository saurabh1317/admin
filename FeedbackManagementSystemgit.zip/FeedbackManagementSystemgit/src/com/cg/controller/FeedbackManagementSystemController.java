package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.CourseMaster;
import com.cg.entities.EmployeeMaster;
import com.cg.service.IFeedbackManagementSystemService;

@Controller
public class FeedbackManagementSystemController {

	
//---------------------------------------------------------------------------	
	
	//Autowiring Service
	@Autowired
	IFeedbackManagementSystemService service;

	public IFeedbackManagementSystemService getService() {
		return service;
	}

	public void setService(IFeedbackManagementSystemService service) {
		this.service = service;
	}

	
//---------------------------------------------------------------------------	
	
	
	//Login User
	@RequestMapping("Login")
	public String LoginMethod(Model model)
	{
		EmployeeMaster employee=new EmployeeMaster();
		model.addAttribute("employee", employee);
		return "Login";
	}

	@RequestMapping("LoginAction")
	public String LoginAction(Model model,
			@ModelAttribute("employee")EmployeeMaster employee,BindingResult error)
	{
		if(error.hasErrors())
		{
			return "Error";	
		}
		else
		{
			service.LoginUser(employee);
			return "HomePage";

		}

	}
	
	

//---------------------------------------------------------------------------	
	
	
    //Forget Password
	@RequestMapping("ForgetPassword")
	public String ForgetPassword(Model model)
	{
		EmployeeMaster employee=new EmployeeMaster();
		model.addAttribute("employee", employee);
		return "ForgetPassword";
	}

	@RequestMapping("ForgetPasswordAction")
	public String ForgetPasswordAction(Model model,
			@ModelAttribute("employee")EmployeeMaster employee,BindingResult error)
	{

		
		if(error.hasErrors())
		{
			return "Error";	
		}
		else
		{
			service.ForgetPassword(employee);
			return "ForgetPasswordSuccess";

		}
	}


	
//---------------------------------------------------------------------------	
	
	
	//Register New User
	@RequestMapping("RegisterNewUser")
	public String RegisterNewUser(Model model)
	{
		EmployeeMaster employee=new EmployeeMaster();
		model.addAttribute("employee", employee);
		return "RegisterNewUser";
	}

	@RequestMapping("RegisterNewUserAction")
	public String RegisterNewUserAction(Model model,
			@ModelAttribute("employee")EmployeeMaster employee,BindingResult error)
	{
		
		if(error.hasErrors())
		{
			return "Error";	
		}
		else
		{
			service.RegisterNewUser(employee);

			return "RegisterNewUserSuccess";

		}

	}

	
	
//---------------------------------------------------------------------------	

	//Faculty Maintenance
	
	@RequestMapping("FacultyMaintenance")
	public String FcaultyMaintenance()
	{
		return "FacultyMaintenance";
	}
	
	
//---------------------------------------------------------------------------
    
	//Course Maintenance
	
	@RequestMapping("CourseMaintenance")
	public String CourseMaintenance()
	{
		return "CourseMaintenance";
	}
	
	
	
	
	//Add new Course
	
	@RequestMapping("AddNewCourse")
	public String AddNewCourse(Model model)
	{
		CourseMaster course=new CourseMaster();
		model.addAttribute("course", course);
		return "AddNewCourse";
	}
	
	@RequestMapping("AddNewCourseAction")
	public String AddNewCourseAction(Model model,
			@ModelAttribute("course")CourseMaster course,BindingResult error)
	{
		
		if(error.hasErrors())
		{
			return "Error";	
		}
		else
		{
			service.AddNewCourse(course);

			return "AddNewCourseSuccess";

		}
		
	}
	
	
	
	
	//List All Course
	
	
	@RequestMapping("ListAllCourse")
	public String ListAllCourse(Model model)
	{
		List<CourseMaster> list=service.ListAllCourse();
		model.addAttribute("list", list);
		return "ListAllCourse";
	}
	
	
	
	
	
	//Update Course from List
	
	@RequestMapping("UpdateCourse")
	public String UpdateCourse(Model model, 
			@RequestParam("courseId")int courseId)
	{
		CourseMaster cou=service.SearchCourse(courseId);
		model.addAttribute("course", cou);
		return "UpdateCourse";
	}
	
	@RequestMapping("UpdateCourseAction")
	public String UpdateCourseAction(Model model,
			@ModelAttribute("course")CourseMaster course,BindingResult error)
	{
		if(error.hasErrors())
		{
			return "Error";	
		}
		else
		{
			service.UpdateCourse(course);

			return "UpdateCourseSuccess";

		}
		
	}
	
	
	
	
	
	//Delete Course from List
	
	@RequestMapping("DeleteCourse")
	public String DeleteCourse(Model model,
			@RequestParam("courseId")int courseId)
	{
		service.DeleteCourse(courseId);
		return "DeleteCourse";
	}
	
	
	
	//Search Course
	@RequestMapping("SearchCourse")
	public String SearchCourse(Model model)
	{
		CourseMaster course=new CourseMaster();
		model.addAttribute("course", course);
		return "SearchCourse";
	}
	
	@RequestMapping("SearchCourseAction")
	public String SearchCourseAction(Model model,
			@ModelAttribute("course")CourseMaster course)
	{
		CourseMaster cou= service.SearchCourse(course.getCourseId());
		model.addAttribute("course", cou);
		return "ViewSearchCourse";
	}
	
	
//---------------------------------------------------------------------------	
	
	//View Feedback
	@RequestMapping("ViewFeedback")
	public String ViewFeedback()
	{
		return "ViewFeedback";
	}
	
//--------------------------------------------------------------------------
	
	
}
